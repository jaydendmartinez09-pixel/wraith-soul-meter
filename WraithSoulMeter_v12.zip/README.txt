Wraith Soul Meter (v12)
=======================
Your Shiv Eternus econ HUD, benchmarked against Eternus Wraith instead.

Shows next to SOULS (bottom-left):
  - You 15,200 / Eternus Wraith 15,715  @15:00   your net worth (souls + items) vs the Eternus Wraith average
  - DMC soul rank D..SSS: your souls/min over the last 60 s vs the Eternus Wraith pace ("goal")
  - unsecured souls timer, FARM! idle alarm, SPEND reminder, +souls popups

Eternus Wraith net worth (deadlock-api.com, ranked, average badge Eternus, last 30 days, 6,503 games):
  3:00 1,867 | 6:00 4,184 | 9:00 7,486 | 12:00 11,389 | 15:00 15,715 | 20:00 22,912
  25:00 30,502 | 30:00 37,751 | 35:00 44,859 | 40:00 52,449 | 45:00 59,637 | then +1,450/min
  (Eternus Shiv at 20:00 is 19,148: Wraith farms about 20% faster.)

Install: copy "Wraith Soul Meter.vpk" to
  Steam\steamapps\common\Deadlock\game\citadel\addons\pak88_dir.vpk   (any free pakNN number works)
with Deadlock closed.

Works with the Shiv mod (pak02): both carry the same meter. When both are installed, this one runs and picks
the benchmark of the hero you are playing (Wraith or Shiv). On a hero with no data the meter hides.
The rank/idle/spend sounds come from the Shiv mod; without it the meter still works, silently.

Rebuild: python build_wraith.py   (reads the shared soul_extras.js from ..\Shiv Stains of Time and the
match-start layout from the installed game; rebuild after a big Deadlock patch)
F7 console lines start with "[SoulExtras v12 wraith]".
